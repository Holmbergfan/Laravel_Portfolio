<template>
  <div class="project-detail">
    <div class="header">
      <router-link to="/" class="back-link">
        <i class="fas fa-arrow-left"></i>
        Back to Projects
      </router-link>
      <h1>{{ project.title }}</h1>
    </div>

    <div class="main-content">
      <div class="gallery-section">
        <div class="main-image">
          <img v-if="project.mainImage" :src="project.mainImage" :alt="project.title">
          <placeholder-image v-else />
        </div>
        <div v-if="project.images && project.images.length" class="image-gallery">
          <img v-for="image in project.images" 
               :key="image" 
               :src="image" 
               @click="openGallery(image)"
               :alt="project.title">
        </div>
      </div>

      <div class="project-info">
        <div class="info-card status">
          <h3>Project Status</h3>
          <p>{{ project.status }}</p>
        </div>

        <div class="info-grid">
          <div class="info-card">
            <h3>Type</h3>
            <p>{{ project.type }}</p>
          </div>
          <div class="info-card">
            <h3>Category</h3>
            <p>{{ project.category }}</p>
          </div>
          <div class="info-card">
            <h3>Version</h3>
            <p>{{ project.version }}</p>
          </div>
        </div>

        <div class="description-card">
          <h3>Description</h3>
          <p>{{ project.description }}</p>
        </div>

        <div class="actions">
          <a v-if="project.downloadUrl" 
             :href="project.downloadUrl" 
             class="action-button download">
            <i class="fas fa-download"></i>
            Download Project
          </a>
          <a v-if="project.repoUrl" 
             :href="project.repoUrl" 
             target="_blank" 
             class="action-button repo">
            <i class="fab fa-github"></i>
            View Repository
          </a>
        </div>

        <div v-if="project.badges" class="badges">
          <img v-for="badge in project.badges" 
               :key="badge" 
               :src="badge" 
               :alt="badge">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PlaceholderImage from '../components/PlaceholderImage.vue'

export default {
  name: 'ProjectDetail',
  components: {
    PlaceholderImage
  },
  // ... rest of the component logic
}
</script>

<style scoped>
.project-detail {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.header {
  margin-bottom: 2rem;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: #666;
  text-decoration: none;
  margin-bottom: 1rem;
}

.main-content {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
}

.gallery-section {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.main-image {
  width: 100%;
  height: 400px;
  border-radius: 12px;
  overflow: hidden;
}

.main-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-gallery {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 1rem;
}

.image-gallery img {
  width: 100%;
  height: 100px;
  object-fit: cover;
  border-radius: 8px;
  cursor: pointer;
}

.info-card {
  background: white;
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.actions {
  display: flex;
  gap: 1rem;
  margin: 2rem 0;
}

.action-button {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 500;
}

.download {
  background: #28a745;
  color: white;
}

.repo {
  background: #24292e;
  color: white;
}

.badges {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}
</style>
