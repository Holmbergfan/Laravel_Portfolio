<template>
  <div class="file-upload">
    <div class="upload-zone" @drop.prevent="handleDrop" @dragover.prevent>
      <input type="file" ref="fileInput" @change="handleFileSelect" multiple :accept="acceptedTypes" class="hidden">
      <button @click="$refs.fileInput.click()" class="upload-btn">
        <i class="fas fa-cloud-upload-alt"></i>
        Upload Files
      </button>
      <p>Drag & drop files or click to upload</p>
      <p class="accepted-types">Accepted files: Images, .zip, .obj, .stl, etc.</p>
    </div>
    <div v-if="files.length" class="file-list">
      <div v-for="file in files" :key="file.name" class="file-item">
        <span>{{ file.name }}</span>
        <button @click="removeFile(file)" class="remove-btn">
          <i class="fas fa-times"></i>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FileUpload',
  data() {
    return {
      files: [],
      acceptedTypes: '.jpg,.jpeg,.png,.gif,.zip,.obj,.stl,.pdf,.doc,.docx'
    }
  },
  methods: {
    handleFileSelect(event) {
      this.addFiles(event.target.files)
    },
    handleDrop(event) {
      this.addFiles(event.dataTransfer.files)
    },
    addFiles(fileList) {
      const newFiles = Array.from(fileList)
      this.files = [...this.files, ...newFiles]
      this.$emit('files-changed', this.files)
    },
    removeFile(file) {
      this.files = this.files.filter(f => f !== file)
      this.$emit('files-changed', this.files)
    }
  }
}
</script>

<style scoped>
.file-upload {
  width: 100%;
  margin: 1rem 0;
}

.upload-zone {
  border: 2px dashed #ccc;
  padding: 2rem;
  text-align: center;
  border-radius: 8px;
}

.hidden {
  display: none;
}

.upload-btn {
  background: #007bff;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  border: none;
  margin-bottom: 1rem;
  cursor: pointer;
}

.accepted-types {
  color: #666;
  font-size: 0.9rem;
}

.file-list {
  margin-top: 1rem;
}

.file-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem;
  background: #f8f9fa;
  margin: 0.5rem 0;
  border-radius: 4px;
}

.remove-btn {
  background: none;
  border: none;
  color: #dc3545;
  cursor: pointer;
}
</style>
