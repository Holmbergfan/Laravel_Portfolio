<template>
  <div class="placeholder-image" :style="{ width, height }">
    <i class="fas fa-image"></i>
    <span>No image available</span>
  </div>
</template>

<script>
export default {
  name: 'PlaceholderImage',
  props: {
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  }
}
</script>

<style scoped>
.placeholder-image {
  background-color: #f5f5f5;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #666;
}

.placeholder-image i {
  font-size: 3rem;
  margin-bottom: 1rem;
}
</style>
