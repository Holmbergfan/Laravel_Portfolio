<template>
  <div :class="['project-card', project.type]">
    <div class="project-image">
      <img v-if="project.mainImage" :src="project.mainImage" :alt="project.title">
      <placeholder-image v-else />
    </div>
    <div class="project-info">
      <h3>{{ project.title }}</h3>
      <div class="project-meta">
        <span class="type">{{ project.type }}</span>
        <span class="category">{{ project.category }}</span>
      </div>
      <p class="description">{{ project.description }}</p>
      <router-link :to="'/projects/' + project.id" class="view-project">
        View Project
        <i class="fas fa-arrow-right"></i>
      </router-link>
    </div>
  </div>
</template>

<script>
import PlaceholderImage from './PlaceholderImage.vue'

export default {
  name: 'ProjectCard',
  components: {
    PlaceholderImage
  },
  props: {
    project: {
      type: Object,
      required: true
    }
  }
}
</script>

<style scoped>
.project-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin: 1rem;
  transition: transform 0.2s;
}

.project-card:hover {
  transform: translateY(-5px);
}

.project-card.web {
  flex: 0 0 calc(50% - 2rem);
}

.project-card:not(.web) {
  flex: 0 0 calc(33.333% - 2rem);
}

.project-image {
  height: 250px;
  overflow: hidden;
}

.project-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.project-info {
  padding: 1.5rem;
}

.project-meta {
  display: flex;
  gap: 1rem;
  margin: 0.5rem 0;
}

.type, .category {
  background: #f5f5f5;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.9rem;
}

.description {
  margin: 1rem 0;
  color: #666;
}

.view-project {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
}
</style>
