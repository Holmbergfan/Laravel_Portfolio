@extends('layouts.pinory')

@section('title', ucfirst($category) . ' Projects - Holmberg')

@section('content')
<section class="section-container">
    <div class="section-header">
        <h2 class="section-title">{{ ucfirst($category) }} Projects</h2>
    </div>
    <div class="{{ $category }}-grid">
        @foreach($projects as $project)
            <div class="project-card {{ $category }}-card">
                <div class="project-image">
                    @if($project->image)
                        <img src="{{ $project->image }}" alt="{{ $project->title }}">
                    @else
                        <img src="https://via.placeholder.com/400x300?text={{ urlencode($project->title) }}" alt="{{ $project->title }}">
                    @endif
                </div>
                <div class="project-info">
                    <h3>{{ $project->title }}</h3>
                    @if($project->description)
                        <p>{{ $project->description }}</p>
                    @endif
                    <a href="{{ route('projects.show', $project->id) }}" class="btn-secondary">Learn more →</a>
                </div>
            </div>
        @endforeach
    </div>
</section>
@endsection
