<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Holmberg Portfolio')</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/pinory.css') }}">
</head>
<body class="min-h-screen">
    <!-- Navigation -->
    <nav class="glass-panel fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-6 py-4">
            <div class="flex items-center justify-between">
                <a href="{{ route('home') }}" class="text-2xl font-bold gradient-text">
                    HOLMBERG
                </a>
                <div class="hidden md:flex items-center space-x-8">
                    @foreach(['web', '3d', 'apps'] as $category)
                        <a href="{{ route('category.show', $category) }}" 
                           class="hover:text-accent transition-colors">
                            {{ strtoupper($category) }}
                        </a>
                    @endforeach
                    <a href="https://github.com/holmbergfan" target="_blank" 
                       class="btn-gradient">
                        GitHub
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <main class="pt-20 pb-16">
        @yield('content')
    </main>
</body>
</html>