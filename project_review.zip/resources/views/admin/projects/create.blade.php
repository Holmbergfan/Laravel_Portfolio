@extends('layouts.pinory')

@section('title', 'Skapa projekt')

@section('content')
<div class="container mx-auto px-4 py-8">
    <h2 class="text-2xl mb-6">Create New Project</h2>

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.projects.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf

        <!-- Main Image Upload -->
        <div class="mb-4">
            <label class="block text-gray-700">Main Image</label>
            <input type="file" name="main_image" accept="image/*" class="mt-1">
        </div>

        <!-- Gallery Images Upload -->
        <div class="mb-4">
            <label class="block text-gray-700">Gallery Images</label>
            <input type="file" name="gallery_images[]" multiple accept="image/*" class="mt-1">
        </div>

        <!-- Project Files Upload -->
        <div class="mb-4">
            <label class="block text-gray-700">Project Files</label>
            <input type="file" name="files[]" multiple 
                   accept=".zip,.obj,.stl,.pdf,.doc,.docx" class="mt-1">
            <p class="text-sm text-gray-500">Accepted: ZIP, OBJ, STL, PDF, DOC</p>
        </div>

        <div>
            <label for="title">Titel:</label><br>
            <input type="text" name="title" id="title" required>
        </div>

        <div>
            <label for="icon">Ikon (emoji eller class):</label><br>
            <input type="text" name="icon" id="icon" placeholder="🖥️ eller fa-globe" />
        </div>

        <div>
            <label for="category">Kategori:</label><br>
            <select name="category" id="category">
                <option value="">-- Välj kategori --</option>
                <option value="apps">Apps</option>
                <option value="web">Web</option>
                <option value="3d">3D</option>
                <option value="opensource">Open Source</option>
            </select>
        </div>

        <div>
            <label for="repo_url">Repo URL (GitHub etc.):</label><br>
            <input type="text" name="repo_url" id="repo_url" placeholder="https://github.com/..." />
        </div>

        <div>
            <label for="image_url">Bild-URL (skärmdump):</label><br>
            <input type="text" name="image_url" id="image_url" placeholder="https://..." />
        </div>

        <div>
            <label for="status">Status:</label><br>
            <input type="text" name="status" id="status" placeholder="Open Source / Proprietary" />
        </div>

        <div>
            <label for="type">Typ:</label><br>
            <input type="text" name="type" id="type" placeholder="Windows, Mac, Web..." />
        </div>

        <div>
            <label for="version">Version:</label><br>
            <input type="text" name="version" id="version" placeholder="Ex: v1.0.0" />
        </div>

        <div>
            <label for="download_url">Nedladdningslänk:</label><br>
            <input type="text" name="download_url" id="download_url" placeholder="https://..." />
        </div>

        <div>
            <label for="badges">Badges (komma-separerade):</label><br>
            <input type="text" name="badges" id="badges" placeholder="Open Source, Windows, Beta" />
        </div>

        <div>
            <label for="version_history">Versionshistorik:</label><br>
            <textarea name="version_history" id="version_history" rows="3" placeholder="Lista versioner eller ändringslogg"></textarea>
        </div>

        <div>
            <label for="description">Beskrivning:</label><br>
            <textarea name="description" id="description" rows="4"></textarea>
        </div>

        <br>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
            Create Project
        </button>
    </form>
</div>
@endsection
