@extends('layouts.pinory')

@section('content')
<section class="max-w-7xl mx-auto px-6 py-16">
    <!-- Hero Section -->
    <div class="text-center mb-20">
        <h1 class="text-5xl font-bold gradient-text mb-6">
            Secure Digital Solutions
        </h1>
        <p class="text-xl text-slate-400 mb-8">
            Building privacy-focused applications with modern security practices
        </p>
        <div class="flex justify-center gap-4">
            <a href="#projects" class="btn-gradient">
                View Projects
            </a>
            <a href="https://github.com/holmbergfan" 
               class="border border-accent rounded-lg px-6 py-3 hover:bg-accent/10 transition">
                GitHub Profile
            </a>
        </div>
    </div>

    <!-- Projects Grid -->
    @foreach(['web', '3d', 'apps'] as $category)
        <section class="mb-20">
            <div class="section-header">
                <h2 class="text-3xl font-bold mb-4">{{ ucfirst($category) }} Projects</h2>
                <a href="{{ route('category.show', $category) }}" class="text-accent hover:underline">
                    View All →
                </a>
            </div>
            
            <div class="projects-grid">
                @foreach($projects->where('category', $category)->take(3) as $project)
                    <div class="project-card">
                        <div class="p-6">
                            @if($project->image_url)
                                <img src="{{ $project->image_url }}" alt="{{ $project->title }}" 
                                     class="w-full h-48 object-cover rounded-lg mb-4">
                            @endif
                            <h3 class="text-xl font-semibold mb-2">{{ $project->title }}</h3>
                            <div class="flex flex-wrap gap-2 mb-4">
                                @if($project->is_opensource)
                                    <span class="px-3 py-1 rounded-full bg-success/20 text-success text-sm">
                                        Open Source
                                    </span>
                                @endif
                                <span class="px-3 py-1 rounded-full bg-accent/20 text-accent text-sm">
                                    {{ $project->type }}
                                </span>
                            </div>
                            <p class="text-slate-400 mb-4">{{ Str::limit($project->description, 100) }}</p>
                            <a href="{{ route('projects.show', $project->id) }}" 
                               class="inline-flex items-center text-accent hover:underline">
                                Learn More →
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </section>
    @endforeach
</section>
@endsection