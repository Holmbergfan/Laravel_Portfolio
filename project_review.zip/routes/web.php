<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\CategoryController;

// Startsida (om du vill visa en "welcome" eller portfolio)
Route::get('/', [PortfolioController::class, 'index'])->name('home');
Route::get('/projects/{id}', [ProjectController::class, 'show'])->name('projects.show');

// Inloggning
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');

// Category routes
Route::get('/category/{category}', [CategoryController::class, 'show'])->name('category.show');

// Admin-sidor (kräver inloggning via 'auth:web')
Route::middleware('auth:web')->prefix('admin')->name('admin.')->group(function() {
    // CRUD för Projects
    Route::get('/projects', [ProjectController::class, 'index'])->name('projects.index');
    Route::get('/projects/create', [ProjectController::class, 'create'])->name('projects.create');
    Route::post('/projects', [ProjectController::class, 'store'])->name('projects.store');
    Route::get('/projects/{id}/edit', [ProjectController::class, 'edit'])->name('projects.edit');
    Route::put('/projects/{id}', [ProjectController::class, 'update'])->name('projects.update');
    Route::delete('/projects/{id}', [ProjectController::class, 'destroy'])->name('projects.destroy');

    // Logga ut
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});
