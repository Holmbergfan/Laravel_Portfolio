<?php

namespace App\Http\Controllers;

use App\Models\Project;

class PortfolioController extends Controller
{
    public function index()
    {
        $projects = Project::all(); // eller Project::latest()->take(6)->get();
        return view('pinory.home', compact('projects'));
    }
}
