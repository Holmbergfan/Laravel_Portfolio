<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // Visa inloggningssida
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // Hantera inloggning
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        // Försök logga in med web-guard (session)
        if (Auth::guard('web')->attempt($credentials)) {
            // Om lyckad inloggning -> gå till projektlistan
            return redirect()->route('admin.projects.index');
        }

        // Annars, tillbaka med felmeddelande
        return back()->withErrors([
            'email' => 'Fel e-post eller lösenord.',
        ]);
    }

    // Logga ut
    public function logout()
    {
        Auth::guard('web')->logout();
        return redirect()->route('login');
    }
}
