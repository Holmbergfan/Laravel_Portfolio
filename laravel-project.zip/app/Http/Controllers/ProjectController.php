<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProjectController extends Controller
{
    // Lista alla projekt
    public function index()
    {
        $projects = Project::all();
        return view('admin.projects.index', compact('projects'));
    }

    // Visa formulär för att skapa nytt projekt
    public function create()
    {
        return view('admin.projects.create');
    }

    // Spara nytt projekt
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'main_image' => 'nullable|image|max:2048',
            'gallery_images.*' => 'nullable|image|max:2048',
            'files.*' => 'nullable|mimes:zip,obj,stl,pdf,doc,docx|max:10240'
        ]);

        $data = $request->except(['main_image', 'gallery_images', 'files']);

        // Handle main image
        if ($request->hasFile('main_image')) {
            $path = $request->file('main_image')->store('projects/images', 'public');
            $data['image_url'] = Storage::url($path);
        }

        // Handle gallery images
        if ($request->hasFile('gallery_images')) {
            $galleryImages = [];
            foreach ($request->file('gallery_images') as $image) {
                $path = $image->store('projects/gallery', 'public');
                $galleryImages[] = Storage::url($path);
            }
            $data['gallery_images'] = $galleryImages;
        }

        // Handle project files
        if ($request->hasFile('files')) {
            $files = [];
            foreach ($request->file('files') as $file) {
                $path = $file->store('projects/files', 'public');
                $files[] = [
                    'name' => $file->getClientOriginalName(),
                    'path' => Storage::url($path)
                ];
            }
            $data['files'] = json_encode($files);
        }

        Project::create($data);

        return redirect()->route('admin.projects.index')
                        ->with('success', 'Project created successfully!');
    }    

    // Visa formulär för att redigera projekt
    public function edit($id)
    {
        $project = Project::findOrFail($id);
        return view('admin.projects.edit', compact('project'));
    }

    // Uppdatera projekt
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
        ]);

        $project = Project::findOrFail($id);
        $project->update($request->all());

        return redirect()->route('admin.projects.index')
                         ->with('success', 'Projekt uppdaterat!');
    }

    // Ta bort projekt
    public function destroy($id)
    {
        $project = Project::findOrFail($id);
        $project->delete();

        return redirect()->route('admin.projects.index')
                         ->with('success', 'Projekt raderat!');
    }

    public function show($id)
    {
        $project = Project::findOrFail($id);

        // Returnera en vy för att visa projektets detaljsida
        return view('projects.show', compact('project'));
    }
}
