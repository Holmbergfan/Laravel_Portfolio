<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $table = 'projects';

    protected $fillable = [
        'title',
        'description',
        'image_url',
        'gallery_images',
        'status',
        'type',
        'icon',
        'category',
        'version',
        'download_url',
        'repo_url',
        'badges',
        'version_history',
    ];

    protected $casts = [
        'gallery_images' => 'array',
        'badges' => 'array',
    ];
}
