<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Pinory-Liknande')</title>
    <link rel="stylesheet" href="{{ asset('css/pinory.css') }}">
</head>
<body>
    <!-- Sidomeny -->
    <div id="sidebar">
        <h2>Go ahead</h2>
        <ul class="nav-links">
            <!-- Enkla anchor-länkar till sektionerna -->
            <li><a href="#home">HOME</a></li>
            <li><a href="#apps">APPS</a></li>
            <li><a href="#web">WEB</a></li>
            <li><a href="#3d">3D</a></li>
        </ul>
        <div class="theme-toggle">
            THEME MODE ▼
        </div>
    </div>

    <!-- Huvud-innehåll (höger sidan) -->
    <div id="content-wrapper">
        @yield('content')
    </div>
</body>
</html>
