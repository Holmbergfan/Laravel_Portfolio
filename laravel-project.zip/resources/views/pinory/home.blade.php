@extends('layouts.pinory')

@section('title', 'My Crazy Portfolio')

@section('content')
    <!-- HERO -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h1 class="animate-slide-up">HELLO WORLD</h1>
            <p class="subtitle animate-slide-up-delay-1">Creative Developer & 3D Artist</p>
            <p class="animate-slide-up-delay-2">Building digital experiences through code, design, and 3D art.</p>
            <button class="btn-hireme animate-slide-up-delay-3">Explore Projects</button>
        </div>
    </section>

    <!-- APPS SECTION -->
    <section id="apps">
        <h2 class="section-title">Apps</h2>
        <p class="section-subtitle">Here are my Desktop or Mobile Apps</p>

        <div class="card-grid">
            @foreach($projects->where('category', 'apps') as $project)
                <div class="project-card app-card"
                     onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if(!empty($project->image_url))
                        <img src="{{ $project->image_url }}" alt="App Image">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=App+Image" alt="Placeholder">
                    @endif

                    <h3>{{ $project->title }}</h3>
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 80) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- WEB SECTION -->
    <section id="web">
        <h2 class="section-title">Web Projects</h2>
        <p class="section-subtitle">Bigger images for web stuff maybe</p>

        <div class="card-grid">
            @foreach($projects->where('category', 'web') as $project)
                <div class="project-card web-card"
                     onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if(!empty($project->image_url))
                        <img src="{{ $project->image_url }}" alt="Web Project">
                    @else
                        <img src="https://via.placeholder.com/400x300?text=Web+Project" alt="Placeholder">
                    @endif

                    <h3>{{ $project->title }}</h3>
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 80) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- 3D SECTION -->
    <section id="3d">
        <h2 class="section-title">3D Models</h2>
        <p class="section-subtitle">Shots of 3D models or animations</p>

        <div class="card-grid">
            @foreach($projects->where('category', '3d') as $project)
                <div class="project-card threed-card"
                     onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if(!empty($project->image_url))
                        <img src="{{ $project->image_url }}" alt="3D Model">
                    @else
                        <img src="https://via.placeholder.com/300x300?text=3D+Model" alt="Placeholder">
                    @endif

                    <h3>{{ $project->title }}</h3>
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 80) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- OPEN SOURCE SECTION -->
    <section id="opensource">
        <h2 class="section-title">Open Source</h2>
        <p class="section-subtitle">Check out my GitHub repos!</p>

        <div class="card-grid">
            @foreach($projects->where('category', 'opensource') as $project)
                <div class="project-card opensource-card"
                     onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if(!empty($project->image_url))
                        <img src="{{ $project->image_url }}" alt="Repo Image">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=Open+Source" alt="Placeholder">
                    @endif

                    <h3>{{ $project->title }}</h3>
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 80) }}</p>
                </div>
            @endforeach
        </div>
    </section>
@endsection

<style>
@keyframes slideUp {
    from { transform: translateY(30px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.animate-slide-up {
    animation: slideUp 0.6s ease forwards;
}

.animate-slide-up-delay-1 {
    animation: slideUp 0.6s ease forwards;
    animation-delay: 0.2s;
    opacity: 0;
}

.animate-slide-up-delay-2 {
    animation: slideUp 0.6s ease forwards;
    animation-delay: 0.4s;
    opacity: 0;
}

.animate-slide-up-delay-3 {
    animation: slideUp 0.6s ease forwards;
    animation-delay: 0.6s;
    opacity: 0;
}
</style>
