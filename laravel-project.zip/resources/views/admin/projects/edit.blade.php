@extends('layouts.pinory')

@section('title', 'Redigera projekt')

@section('content')
<h2>Redigera projekt</h2>

@if ($errors->any())
    <div style="color: red;">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('admin.projects.update', $project->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div>
        <label for="title">Titel:</label><br>
        <input type="text" name="title" id="title" value="{{ $project->title }}" required>
    </div>

    <div>
        <label for="icon">Ikon (emoji eller class):</label><br>
        <input type="text" name="icon" id="icon" value="{{ $project->icon }}">
    </div>

    <div>
        <label for="category">Kategori:</label><br>
        <select name="category" id="category">
            <option value="">-- Välj kategori --</option>
            <option value="apps" @if($project->category=='apps') selected @endif>Apps</option>
            <option value="web" @if($project->category=='web') selected @endif>Web</option>
            <option value="3d" @if($project->category=='3d') selected @endif>3D</option>
            <option value="opensource" @if($project->category=='opensource') selected @endif>Open Source</option>
        </select>
    </div>

    <div>
        <label for="repo_url">Repo URL (GitHub etc.):</label><br>
        <input type="text" name="repo_url" id="repo_url" value="{{ $project->repo_url }}">
    </div>

    <div>
        <label for="image_url">Bild-URL:</label><br>
        <input type="text" name="image_url" id="image_url" value="{{ $project->image_url }}">
    </div>

    <div>
        <label for="status">Status:</label><br>
        <input type="text" name="status" id="status" value="{{ $project->status }}">
    </div>

    <div>
        <label for="type">Typ:</label><br>
        <input type="text" name="type" id="type" value="{{ $project->type }}">
    </div>

    <div>
        <label for="version">Version:</label><br>
        <input type="text" name="version" id="version" value="{{ $project->version }}">
    </div>

    <div>
        <label for="download_url">Nedladdningslänk:</label><br>
        <input type="text" name="download_url" id="download_url" value="{{ $project->download_url }}">
    </div>

    <div>
        <label for="badges">Badges (komma-separerade):</label><br>
        <input type="text" name="badges" id="badges" value="{{ $project->badges }}">
    </div>

    <div>
        <label for="version_history">Versionshistorik:</label><br>
        <textarea name="version_history" id="version_history" rows="3">{{ $project->version_history }}</textarea>
    </div>

    <div>
        <label for="description">Beskrivning:</label><br>
        <textarea name="description" id="description" rows="4">{{ $project->description }}</textarea>
    </div>

    <br>
    <button type="submit">Uppdatera</button>
</form>
@endsection
