@extends('layouts.pinory')

@section('title', 'Admin - Projektlista')

@section('content')
<div class="admin-dashboard">
    <div class="admin-header">
        <h2 class="section-title">Projektlista (Admin)</h2>
        <a href="{{ route('admin.projects.create') }}" class="admin-btn create-btn">
            <i class="fas fa-plus"></i> Skapa nytt projekt
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="projects-grid">
        @foreach($projects as $project)
            <div class="project-card admin">
                <div class="project-header">
                    <div class="project-icon">{{ $project->icon }}</div>
                    <div class="project-status {{ strtolower($project->status) }}">{{ $project->status }}</div>
                </div>
                
                <div class="project-body">
                    <h3>{{ $project->title }}</h3>
                    <div class="project-meta">
                        <span class="category">{{ $project->category }}</span>
                        <span class="version">{{ $project->version }}</span>
                    </div>
                    <p class="description">{{ Str::limit($project->description, 100) }}</p>
                </div>

                <div class="project-actions">
                    <a href="{{ route('admin.projects.edit', $project->id) }}" class="edit-btn">
                        <i class="fas fa-edit"></i> Redigera
                    </a>
                    <form action="{{ route('admin.projects.destroy', $project->id) }}" 
                          method="POST" 
                          onsubmit="return confirm('Är du säker på att du vill radera detta projekt?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="delete-btn">
                            <i class="fas fa-trash"></i> Radera
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>

    <div class="admin-footer">
        <form action="{{ route('admin.logout') }}" method="POST">
            @csrf
            <button type="submit" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logga ut
            </button>
        </form>
    </div>
</div>
@endsection
