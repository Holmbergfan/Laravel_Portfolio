@extends('layouts.pinory')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Image and Gallery Section -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                @if($project->image_url)
                    <img src="{{ $project->image_url }}" alt="{{ $project->title }}" 
                         class="w-full h-96 object-cover">
                @else
                    <div class="w-full h-96 bg-gray-200 flex items-center justify-center">
                        <span class="text-gray-400">No image available</span>
                    </div>
                @endif
            </div>

            @if($project->gallery_images)
            <div class="mt-6 grid grid-cols-3 gap-4">
                @foreach(json_decode($project->gallery_images) as $image)
                <div class="aspect-square">
                    <img src="{{ $image }}" alt="Gallery image" 
                         class="w-full h-full object-cover rounded-lg cursor-pointer"
                         onclick="openGallery('{{ $image }}')">
                </div>
                @endforeach
            </div>
            @endif
        </div>

        <!-- Project Info Section -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h1 class="text-2xl font-bold mb-4">{{ $project->title }}</h1>
                
                <div class="space-y-4">
                    <div>
                        <h3 class="font-semibold">Status</h3>
                        <p>{{ $project->status }}</p>
                    </div>

                    <div>
                        <h3 class="font-semibold">Type</h3>
                        <p>{{ $project->type }}</p>
                    </div>

                    <div>
                        <h3 class="font-semibold">Category</h3>
                        <p>{{ $project->category }}</p>
                    </div>

                    @if($project->description)
                    <div>
                        <h3 class="font-semibold">Description</h3>
                        <p class="whitespace-pre-line">{{ $project->description }}</p>
                    </div>
                    @endif

                    @if($project->repo_url)
                    <div>
                        <h3 class="font-semibold">Repository</h3>
                        <a href="{{ $project->repo_url }}" target="_blank" 
                           class="text-blue-500 hover:underline">
                            View Repository
                        </a>
                    </div>
                    @endif

                    @if($project->download_url)
                    <div>
                        <h3 class="font-semibold">Download</h3>
                        <a href="{{ $project->download_url }}" 
                           class="inline-block bg-blue-500 text-white px-4 py-2 rounded">
                            Download Project
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Gallery Modal -->
<div id="gallery-modal" class="hidden fixed inset-0 bg-black bg-opacity-90 z-50">
    <div class="absolute inset-0 flex items-center justify-center">
        <img id="gallery-image" src="" alt="Gallery image" class="max-w-90vw max-h-90vh">
        <button onclick="closeGallery()" 
                class="absolute top-4 right-4 text-white text-2xl">&times;</button>
    </div>
</div>

<script>
function openGallery(imageUrl) {
    document.getElementById('gallery-image').src = imageUrl;
    document.getElementById('gallery-modal').classList.remove('hidden');
}

function closeGallery() {
    document.getElementById('gallery-modal').classList.add('hidden');
}
</script>
@endsection
