@extends('layouts.pinory')

@section('title', $project->title)

@section('content')
<div id="content-wrapper">
    <div class="show-project-container">
        <h1>{{ $project->title }}</h1>

        @if($project->icon)
            <div style="font-size: 3rem; margin: 0.5rem 0;">{{ $project->icon }}</div>
        @endif

        @if($project->image_url)
            <img src="{{ $project->image_url }}" alt="Screenshot" class="project-img">
        @else
            <img src="https://via.placeholder.com/600x300?text=No+Image" class="project-img" alt="No image">
        @endif

        <p style="color: #aaa;">Screenshot</p>

        <p><strong>Status:</strong> {{ $project->status }}</p>
        <p><strong>Typ:</strong> {{ $project->type }}</p>
        <p><strong>Kategori:</strong> {{ $project->category }}</p>
        <p><strong>Version:</strong> {{ $project->version }}</p>

        @if($project->download_url)
            <p><strong>Nedladdning:</strong>
                <a href="{{ $project->download_url }}" target="_blank" style="color: #0ff;">
                    Ladda ner här
                </a>
            </p>
        @endif

        @if($project->repo_url)
            <p><strong>Repo (GitHub m.m.):</strong><br>
                <a href="{{ $project->repo_url }}" target="_blank" style="color: #0ff;">
                    {{ $project->repo_url }}
                </a>
            </p>
        @endif

        @if($project->badges)
            <p><strong>Badges:</strong><br>
                @foreach(explode(',', $project->badges) as $badge)
                    <span class="badge">{{ trim($badge) }}</span>
                @endforeach
            </p>
        @endif

        @if($project->description)
            <p><strong>Beskrivning:</strong><br>
            {!! nl2br(e($project->description)) !!}</p>
        @endif

        @if($project->version_history)
            <h3>Versionshistorik</h3>
            <pre style="background: #333; color: #eee; padding: 1rem;">
{{ $project->version_history }}
            </pre>
        @endif
    </div>

    <p style="margin-top: 1rem;">
        <a href="{{ route('home') }}" style="color: var(--accent-color);">← Tillbaka till startsidan</a>
    </p>
</div>
@endsection
