@extends('layouts.pinory')

@section('title', ucfirst($category) . ' Projects')

@section('content')
<section class="category-page">
    <div class="section-header">
        <h1 class="section-title">{{ ucfirst($category) }} Projects</h1>
        <a href="{{ route('home') }}" class="back-link">← Back to home</a>
    </div>

    <div class="project-grid">
        @foreach($projects as $project)
            <div class="project-card">
                <div class="project-image">
                    @if(!empty($project->image_url))
                        <img src="{{ $project->image_url }}" alt="{{ $project->title }}">
                    @else
                        <img src="https://via.placeholder.com/600x400" alt="Placeholder">
                    @endif
                </div>
                <div class="project-info">
                    <h3>{{ $project->title }}</h3>
                    @if($project->is_opensource)
                        <span class="badge opensource">Open Source</span>
                    @endif
                    <p>{{ \Illuminate\Support\Str::limit($project->description, 100) }}</p>
                    <a href="{{ route('projects.show', $project->id) }}" class="btn-secondary">Learn more →</a>
                </div>
            </div>
        @endforeach
    </div>
</section>

<style>
.category-page {
    padding: 2rem;
}

.back-link {
    color: var(--accent-color);
    text-decoration: none;
}

.back-link:hover {
    text-decoration: underline;
}

.project-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}
</style>
@endsection
