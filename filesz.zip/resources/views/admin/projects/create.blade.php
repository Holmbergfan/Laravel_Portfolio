@extends('layouts.pinory')

@section('title', 'Skapa projekt')

@section('content')
<div id="content-wrapper">
    <h2 class="section-title">Skapa nytt projekt</h2>
    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.projects.store') }}" method="POST">
        @csrf
        <div>
            <label for="title">Titel:</label><br>
            <input type="text" id="title" name="title" required />
        </div>

        <div>
            <label for="category">Kategori (apps, web, 3d, opensource):</label><br>
            <input type="text" id="category" name="category" />
        </div>

        <div>
            <label for="description">Beskrivning:</label><br>
            <textarea name="description" id="description" rows="4"></textarea>
        </div>

        <div>
            <label for="image_url">Bild-URL:</label><br>
            <input type="text" id="image_url" name="image_url" />
        </div>

        <div>
            <label for="status">Status:</label><br>
            <input type="text" id="status" name="status" placeholder="Open Source / Proprietary" />
        </div>

        <div>
            <label for="type">Typ:</label><br>
            <input type="text" id="type" name="type" placeholder="Windows, Mac..." />
        </div>

        <div>
            <label for="version">Version:</label><br>
            <input type="text" id="version" name="version" />
        </div>

        <div>
            <label for="download_url">Nedladdningslänk:</label><br>
            <input type="text" id="download_url" name="download_url" />
        </div>

        <div>
            <label for="repo_url">Repo URL (GitHub etc.):</label><br>
            <input type="text" id="repo_url" name="repo_url" />
        </div>

        <div>
            <label for="badges">Badges (komma-separerade):</label><br>
            <input type="text" id="badges" name="badges" placeholder="Open Source, Beta" />
        </div>

        <div>
            <label for="version_history">Versionshistorik:</label><br>
            <textarea name="version_history" id="version_history" rows="3"></textarea>
        </div>

        <br>
        <button type="submit" class="btn-cta">Spara</button>
    </form>
</div>
@endsection
