@extends('layouts.pinory')

@section('title', 'Redigera projekt')

@section('content')
<div id="content-wrapper">
    <h2 class="section-title">Redigera projekt</h2>
    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.projects.update', $project->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div>
            <label for="title">Titel:</label><br>
            <input type="text" name="title" id="title" value="{{ $project->title }}" required />
        </div>

        <!-- Repeat for category, description, image_url, etc. -->
        <div>
            <label for="category">Kategori:</label><br>
            <input type="text" id="category" name="category" value="{{ $project->category }}" />
        </div>

        <div>
            <label for="description">Beskrivning:</label><br>
            <textarea name="description" id="description" rows="4">{{ $project->description }}</textarea>
        </div>

        <!-- ...osv för image_url, status, type, version, download_url, repo_url, badges, version_history -->

        <br>
        <button type="submit" class="btn-cta">Uppdatera</button>
    </form>
</div>
@endsection
