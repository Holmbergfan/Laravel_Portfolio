@extends('layouts.pinory')

@section('title', 'Admin - Projektlista')

@section('content')
<div id="content-wrapper">
    <h2 class="section-title">Projektlista (Admin)</h2>

    @if(session('success'))
        <p style="color: lightgreen;">{{ session('success') }}</p>
    @endif

    <p><a href="{{ route('admin.projects.create') }}" style="color: var(--accent-color);">[Skapa nytt projekt]</a></p>

    <ul>
        @foreach($projects as $project)
            <li>
                <strong>{{ $project->title }}</strong> (Kategori: {{ $project->category }})
                <a href="{{ route('admin.projects.edit', $project->id) }}" style="margin-left: 1rem;">Redigera</a>
                <form action="{{ route('admin.projects.destroy', $project->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn-cta" style="padding: 0.3rem 0.5rem; margin-left: 1rem;">
                        Radera
                    </button>
                </form>
            </li>
        @endforeach
    </ul>

    <form action="{{ route('admin.logout') }}" method="POST" style="margin-top: 2rem;">
        @csrf
        <button type="submit" class="btn-cta">Logga ut</button>
    </form>
</div>
@endsection
