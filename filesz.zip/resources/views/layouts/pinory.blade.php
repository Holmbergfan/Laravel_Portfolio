<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Basistheory-like')</title>
    <link rel="stylesheet" href="{{ asset('css/pinory.css') }}">
</head>
<body>

    <!-- Top Navigation -->
    <div id="top-nav">
        <a href="{{ url('/') }}" class="logo">MY PORTFOLIO</a>
        <ul class="nav-links">
            <li><a href="{{ url('/') }}#home">Home</a></li>
            <li><a href="{{ url('/') }}#apps">Apps</a></li>
            <li><a href="{{ url('/') }}#web">Web</a></li>
            <li><a href="{{ url('/') }}#3d">3D</a></li>
            <li><a href="{{ url('/') }}#opensource">Open Source</a></li>
        </ul>
    </div>

    @yield('content')

</body>
</html>
