<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8" />
    <title>@yield('title', 'Holmberg Admin')</title>
    <style>
        body {
            margin: 0; padding: 0;
            background: #222;
            color: #fff;
            font-family: sans-serif;
        }
        header {
            background: #333;
            padding: 20px;
        }
        header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        .container {
            margin: 20px;
            padding: 20px;
            background: #444;
            border-radius: 8px;
        }
        a, button {
            color: #0ff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header>
        <h1>Holmberg Admin</h1>
    </header>
    <div class="container">
        @yield('content')
    </div>
</body>
</html>
