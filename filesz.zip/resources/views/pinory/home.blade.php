@extends('layouts.pinory')

@section('title', 'My Crazy Portfolio')

@section('content')
    <!-- HERO -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h1>HELLO WORLD</h1>
            <p class="subtitle">Wait, what's going on?</p>
            <p>It's my portfolio, not a serious business. Enjoy or leave!</p>
            <button class="btn-cta">You can't hire me</button>
        </div>
    </section>

    <!-- APPS SECTION -->
    <section id="apps">
        <h2 class="section-title">APPS</h2>
        <p class="section-subtitle">Here are my Desktop or Mobile Apps</p>
        <div class="card-grid">
            @foreach($projects->where('category', 'apps') as $project)
                <div class="project-card" onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if($project->image_url)
                        <img src="{{ $project->image_url }}" alt="App Image" class="project-img">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=App+Image" class="project-img" alt="Placeholder">
                    @endif
                    <h3>{{ $project->title }}</h3>
                    <p>{{ Str::limit($project->description, 60) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- WEB SECTION -->
    <section id="web">
        <h2 class="section-title">WEB PROJECTS</h2>
        <p class="section-subtitle">Bigger images for web stuff maybe</p>
        <div class="card-grid">
            @foreach($projects->where('category', 'web') as $project)
                <div class="project-card" onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if($project->image_url)
                        <img src="{{ $project->image_url }}" alt="Web Project" class="project-img">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=Web+Project" class="project-img" alt="Placeholder">
                    @endif
                    <h3>{{ $project->title }}</h3>
                    <p>{{ Str::limit($project->description, 60) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- 3D SECTION -->
    <section id="3d">
        <h2 class="section-title">3D MODELS</h2>
        <p class="section-subtitle">Shots of 3D models or animations</p>
        <div class="card-grid">
            @foreach($projects->where('category', '3d') as $project)
                <div class="project-card" onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if($project->image_url)
                        <img src="{{ $project->image_url }}" alt="3D" class="project-img">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=3D+Model" class="project-img" alt="Placeholder">
                    @endif
                    <h3>{{ $project->title }}</h3>
                    <p>{{ Str::limit($project->description, 60) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <!-- OPEN SOURCE SECTION -->
    <section id="opensource">
        <h2 class="section-title">OPEN SOURCE</h2>
        <p class="section-subtitle">Check out my GitHub repos!</p>
        <div class="card-grid">
            @foreach($projects->where('category', 'opensource') as $project)
                <div class="project-card" onclick="location.href='{{ route('projects.show', $project->id) }}'">
                    @if($project->image_url)
                        <img src="{{ $project->image_url }}" alt="Repo Image" class="project-img">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=Repo+Image" class="project-img" alt="Placeholder">
                    @endif
                    <h3>{{ $project->title }}</h3>
                    <p>{{ Str::limit($project->description, 60) }}</p>
                </div>
            @endforeach
        </div>
    </section>

    <footer>
        <p>&copy; {{ date('Y') }} My Portfolio. All Rights Reserved.</p>
    </footer>
@endsection
